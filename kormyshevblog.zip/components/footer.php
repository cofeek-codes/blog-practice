<!-- footer -->
<footer class="py-3 my-4 mt-auto">
  <div class="nav justify-content-center border-bottom pb-3 mb-3">
    <h1 class="text-center">Пусть ваш день будет продуктивным!</h1>
  </div>
  <p class="text-center text-body-secondary">© 2024 cofeek-codes</p>
</footer>
<!-- footer -->