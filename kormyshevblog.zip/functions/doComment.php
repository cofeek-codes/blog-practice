<?php


print_r($_POST);
